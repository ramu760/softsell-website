function MainContent() {
    return (
      <>
        {/* Hero Section */}
        <main className="p-10 text-center bg-gray-50 min-h-[80vh] flex flex-col justify-center items-center">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Grow Your Sales with SoftSell</h2>
          <p className="text-gray-600 text-lg max-w-xl mb-6">
            We help businesses turn visitors into loyal customers with powerful and elegant landing pages.
          </p>
          <button className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition">
            Get Started
          </button>
        </main>
  
        {/* About / Features Section */}
        <section className="bg-white py-16 px-6">
          <div className="max-w-5xl mx-auto text-center">
            <h3 className="text-3xl font-bold text-gray-800 mb-8">Why Choose SoftSell?</h3>
            <div className="grid md:grid-cols-3 gap-8 text-left">
              <div className="p-6 shadow rounded bg-gray-50">
                <h4 className="text-xl font-semibold mb-2 text-blue-600">Fast Performance</h4>
                <p className="text-gray-600">Our landing pages are optimized for speed to boost conversions.</p>
              </div>
              <div className="p-6 shadow rounded bg-gray-50">
                <h4 className="text-xl font-semibold mb-2 text-blue-600">Responsive Design</h4>
                <p className="text-gray-600">Looks great on all devices — desktops, tablets, and phones.</p>
              </div>
              <div className="p-6 shadow rounded bg-gray-50">
                <h4 className="text-xl font-semibold mb-2 text-blue-600">Easy to Customize</h4>
                <p className="text-gray-600">Easily edit and update content to suit your brand and needs.</p>
              </div>
            </div>
          </div>
        </section>
      </>
    );
  }
  
  export default MainContent;